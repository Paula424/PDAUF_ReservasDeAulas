package com.paulapdp.ReservasDeAulas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservasDeAulasApplicationTests {

	@Test
	void contextLoads() {
	}

}
