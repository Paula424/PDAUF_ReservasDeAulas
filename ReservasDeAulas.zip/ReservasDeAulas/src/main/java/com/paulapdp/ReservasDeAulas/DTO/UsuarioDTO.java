package com.paulapdp.ReservasDeAulas.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * DTO de respuesta con datos de un USUARIO
 *
 * Se devuelve cuando se consulta información de usuarios.
 * NO incluye la contraseña por seguridad.
 *
 * Ejemplo JSON:
 * {
 *   "id": 1,
 *   "nombre": "Juan Pérez",
 *   "email": "juan.perez@colegio.es",
 *   "role": "ROLE_PROFESOR",
 *   "enabled": true
 * }
 */
public record UsuarioDTO(
        Long id,
        String nombre,
        String email,
        String role,
        boolean enabled
) {}
