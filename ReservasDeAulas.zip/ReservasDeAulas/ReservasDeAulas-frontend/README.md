# Frontend de Reservas de Aulas (Generado con IA)
Este proyecto es una interfaz web sencilla para interactuar con la API REST de Reservas de Aulas.
## Comandos
- Instalar dependencias: `npm install`
- Ejecutar: `npm start`
Asegúrate de que el backend esté ejecutándose en `http://localhost:8080`.
